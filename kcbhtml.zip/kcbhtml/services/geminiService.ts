import { Course } from "../types";

// Helper to convert File to Base64
export const fileToGenerativePart = async (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const parseScheduleFromImage = async (base64Image: string, mimeType: string): Promise<Omit<Course, 'id' | 'color'>[]> => {
  try {
    const res = await fetch('/api/parse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base64Image, mimeType })
    })
    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      throw new Error(err?.error || '解析失败')
    }
    const data = await res.json()
    return data as Omit<Course, 'id' | 'color'>[]
  } catch (error: any) {
    console.error('Parse API Error:', error)
    throw new Error(error?.message || '无法识别课程表，请确保图片清晰。')
  }
}
