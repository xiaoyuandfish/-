import React, { useState, useEffect } from 'react';
import { Course, DAYS, PERIODS } from '../types';
import { X, Trash2, Save } from 'lucide-react';

interface CourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (course: Course) => void;
  onDelete: (id: string) => void;
  initialData?: Course | null;
  selectedSlot?: { day: number; period: number } | null;
}

const CourseModal: React.FC<CourseModalProps> = ({ 
  isOpen, 
  onClose, 
  onSave, 
  onDelete, 
  initialData, 
  selectedSlot 
}) => {
  const [formData, setFormData] = useState<Partial<Course>>({
    name: '',
    teacher: '',
    location: '',
    dayOfWeek: 1,
    startPeriod: 1,
    duration: 2,
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else if (selectedSlot) {
      setFormData({
        name: '',
        teacher: '',
        location: '',
        dayOfWeek: selectedSlot.day,
        startPeriod: selectedSlot.period,
        duration: 2,
      });
    } else {
      setFormData({
        name: '',
        teacher: '',
        location: '',
        dayOfWeek: 1,
        startPeriod: 1,
        duration: 2,
      });
    }
  }, [initialData, selectedSlot, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    
    const courseToSave = {
      ...formData,
      id: initialData?.id || crypto.randomUUID(),
      // Assign a random color if new
      color: initialData?.color || undefined 
    } as Course;

    onSave(courseToSave);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden transform transition-all">
        <div className="flex justify-between items-center p-4 border-b bg-gray-50">
          <h2 className="text-lg font-bold text-gray-800">
            {initialData ? '编辑课程' : '添加课程'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">课程名称</label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition"
              placeholder="例如：高等数学"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">教师</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="教师姓名"
                value={formData.teacher}
                onChange={(e) => setFormData({ ...formData, teacher: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">地点</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="例如：A101"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
             <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">星期</label>
              <select
                className="w-full px-2 py-2 border border-gray-300 rounded-lg outline-none"
                value={formData.dayOfWeek}
                onChange={(e) => setFormData({ ...formData, dayOfWeek: Number(e.target.value) })}
              >
                {DAYS.map((day, idx) => (
                  <option key={idx} value={idx + 1}>{day}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">开始节次</label>
              <select
                className="w-full px-2 py-2 border border-gray-300 rounded-lg outline-none"
                value={formData.startPeriod}
                onChange={(e) => setFormData({ ...formData, startPeriod: Number(e.target.value) })}
              >
                {PERIODS.map((p) => (
                  <option key={p} value={p}>第 {p} 节</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">持续节数</label>
              <input
                type="number"
                min="1"
                max="12"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg outline-none"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: Number(e.target.value) })}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t mt-2">
            {initialData && (
              <button
                type="button"
                onClick={() => {
                  if (initialData.id) onDelete(initialData.id);
                  onClose();
                }}
                className="flex items-center justify-center px-4 py-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition"
              >
                <Trash2 size={18} className="mr-2" />
                删除
              </button>
            )}
            <button
              type="submit"
              className="flex-1 flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition shadow-md"
            >
              <Save size={18} className="mr-2" />
              保存
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CourseModal;
