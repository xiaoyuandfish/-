import React, { useRef, useState } from 'react';
import { Upload, Loader2, Sparkles, AlertCircle } from 'lucide-react';
import { fileToGenerativePart, parseScheduleFromImage } from '../services/geminiService';
import { Course, COURSE_COLORS } from '../types';

interface UploadParserProps {
  onParsed: (courses: Course[]) => void;
}

const UploadParser: React.FC<UploadParserProps> = ({ onParsed }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Reset state
    setError(null);
    setIsProcessing(true);

    try {
      if (!file.type.startsWith('image/')) {
        throw new Error("请上传图片文件");
      }

      const base64Data = await fileToGenerativePart(file);
      const parsedCourses = await parseScheduleFromImage(base64Data, file.type);

      // Add IDs and random colors to parsed courses
      const completeCourses: Course[] = parsedCourses.map(c => ({
        ...c,
        id: crypto.randomUUID(),
        color: COURSE_COLORS[Math.floor(Math.random() * COURSE_COLORS.length)]
      }));

      onParsed(completeCourses);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "解析失败，请重试");
    } finally {
      setIsProcessing(false);
      // Clear input so same file can be selected again if needed
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="mb-6">
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        accept="image/*"
        onChange={handleFileChange}
      />
      
      <div className="flex flex-col sm:flex-row items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-indigo-100 gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-100 p-2 rounded-lg">
             <Sparkles className="text-indigo-600" size={24} />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">AI 智能导入</h3>
            <p className="text-sm text-gray-500">上传课程表截图，自动识别课程</p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
            {error && (
                <div className="flex items-center text-red-500 text-sm mr-2 animate-pulse">
                    <AlertCircle size={16} className="mr-1" />
                    {error}
                </div>
            )}
            
            <button
                onClick={triggerUpload}
                disabled={isProcessing}
                className={`w-full sm:w-auto flex items-center justify-center px-6 py-2.5 rounded-lg font-medium transition-all ${
                isProcessing
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white hover:shadow-lg hover:scale-105 active:scale-95'
                }`}
            >
                {isProcessing ? (
                <>
                    <Loader2 className="animate-spin mr-2" size={18} />
                    正在分析...
                </>
                ) : (
                <>
                    <Upload className="mr-2" size={18} />
                    上传图片
                </>
                )}
            </button>
        </div>
      </div>
    </div>
  );
};

export default UploadParser;
