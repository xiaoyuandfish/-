import React from 'react';
import { Course, DAYS, PERIODS, COURSE_COLORS } from '../types';
import { MapPin, User, Plus } from 'lucide-react';

interface TimetableGridProps {
  courses: Course[];
  onSlotClick: (day: number, period: number) => void;
  onCourseClick: (course: Course) => void;
}

const TimetableGrid: React.FC<TimetableGridProps> = ({ courses, onSlotClick, onCourseClick }) => {
  
  // Helper to find courses for a specific cell
  const getCoursesForSlot = (day: number, period: number) => {
    return courses.filter(c => c.dayOfWeek === day && c.startPeriod === period);
  };

  // Helper to check if a cell is occupied by a course extending from a previous period
  const isOccupied = (day: number, period: number) => {
    return courses.some(c => 
      c.dayOfWeek === day && 
      period > c.startPeriod && 
      period < c.startPeriod + c.duration
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden flex flex-col h-full">
      {/* Header Row (Days) */}
      <div className="grid grid-cols-[3rem_repeat(7,1fr)] bg-gray-50 border-b border-gray-200 divide-x divide-gray-200">
        <div className="p-3 flex items-center justify-center text-xs font-bold text-gray-400 uppercase tracking-wider">
          节次
        </div>
        {DAYS.map((day, index) => (
          <div key={index} className="p-3 text-center text-sm font-semibold text-gray-700">
            {day}
          </div>
        ))}
      </div>

      {/* Grid Body */}
      <div className="flex-1 overflow-y-auto no-scrollbar relative">
        <div className="grid grid-cols-[3rem_repeat(7,1fr)] divide-y divide-gray-100 min-w-[600px] h-full">
          {PERIODS.map((period) => (
            <React.Fragment key={period}>
              {/* Period Number Column */}
              <div className="bg-gray-50 flex items-center justify-center text-xs font-medium text-gray-500 border-r border-gray-200 h-24">
                {period}
              </div>

              {/* Days Columns */}
              {Array.from({ length: 7 }, (_, i) => i + 1).map((day) => {
                const slotCourses = getCoursesForSlot(day, period);
                const occupied = isOccupied(day, period);

                // If this slot is occupied by a multi-period course starting above, don't render cell content
                if (occupied) return <div key={`${day}-${period}`} className="border-r border-gray-100/50" />;

                return (
                  <div 
                    key={`${day}-${period}`} 
                    className="relative border-r border-gray-100 p-1 h-24 group hover:bg-gray-50/50 transition-colors"
                  >
                    {/* Empty Slot - Click to Add */}
                    {slotCourses.length === 0 && (
                      <button
                        onClick={() => onSlotClick(day, period)}
                        className="w-full h-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Plus className="text-gray-300 bg-white rounded-full p-1 shadow-sm border" size={24} />
                      </button>
                    )}

                    {/* Courses */}
                    {slotCourses.map((course) => {
                      // Calculate height based on duration
                      const height = `calc(${course.duration * 100}% + ${(course.duration - 1)}px)`;
                      const colorClass = course.color || COURSE_COLORS[0];

                      return (
                        <div
                          key={course.id}
                          onClick={(e) => { e.stopPropagation(); onCourseClick(course); }}
                          className={`
                            absolute top-1 left-1 right-1 z-10 
                            rounded-md p-2 text-xs border shadow-sm 
                            flex flex-col gap-1 ${colorClass}
                            cursor-pointer
                            transition-all duration-200 ease-in-out
                            overflow-hidden 
                            hover:overflow-visible 
                            hover:!h-auto hover:z-50 hover:shadow-xl hover:ring-2 hover:ring-opacity-50 hover:ring-indigo-300
                          `}
                          style={{ height: height, minHeight: '3rem' }}
                        >
                          <div className="font-bold leading-tight break-words">
                            {course.name}
                          </div>
                          
                          {(course.location || course.teacher) && (
                            <div className="mt-auto opacity-90 space-y-1">
                              {course.location && (
                                <div className="flex items-start gap-1">
                                  <MapPin size={10} className="mt-0.5 shrink-0" />
                                  <span className="break-words leading-tight">{course.location}</span>
                                </div>
                              )}
                              {course.teacher && (
                                <div className="flex items-start gap-1">
                                  <User size={10} className="mt-0.5 shrink-0" />
                                  <span className="break-words leading-tight">{course.teacher}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TimetableGrid;