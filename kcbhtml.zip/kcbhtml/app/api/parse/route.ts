import { NextResponse } from 'next/server'
import { GoogleGenAI, Type } from '@google/genai'

export const runtime = 'nodejs'

export async function POST(request: Request) {
  try {
    const { base64Image, mimeType } = await request.json()
    if (!base64Image || !mimeType) {
      return NextResponse.json({ error: '缺少必要参数' }, { status: 400 })
    }

    const apiKey = process.env.GEMINI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: '服务器未配置 GEMINI_API_KEY' }, { status: 500 })
    }

    const ai = new GoogleGenAI({ apiKey })

    const courseSchema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: '课程名称 (Course Name)' },
          teacher: { type: Type.STRING, description: '教师姓名 (Teacher Name)' },
          location: { type: Type.STRING, description: '上课地点 (Location/Classroom)' },
          dayOfWeek: { type: Type.INTEGER, description: '星期几 (1 for Monday, 7 for Sunday)' },
          startPeriod: { type: Type.INTEGER, description: '开始节次 (Start Period 1-12)' },
          duration: { type: Type.INTEGER, description: '持续节数 (Duration in periods)' },
        },
        required: ['name', 'dayOfWeek', 'startPeriod', 'duration'],
      },
    }

    const prompt = `
你是一个专业的大学教务助手。请分析这张课程表图片，提取所有的课程信息。

规则：
1. 仔细识别课程名称、教师、地点、星期几、开始节次和持续节数。
2. 如果没有明确的教师或地点，留空字符串。
3. 星期几请转换为数字：周一=1, 周二=2, ... 周日=7。
4. 节次通常是第1-12节。如果图片显示具体时间（如 8:00-9:40），请根据一般大学作息推断节次（例如8:00通常是第1节）。
5. 返回纯JSON数组。不要包含Markdown格式标记。
`

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Image } },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: courseSchema,
        temperature: 0.1,
      },
    })

    const text = response.text
    if (!text) return NextResponse.json([])
    const jsonString = text.replace(/```json/g, '').replace(/```/g, '').trim()
    const data = JSON.parse(jsonString)
    return NextResponse.json(data)
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || '解析失败' }, { status: 500 })
  }
}

