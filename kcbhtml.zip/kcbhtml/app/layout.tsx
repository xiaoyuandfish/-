'use client'
import React from 'react'
import Script from 'next/script'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'UniSchedule AI',
  description: '基于 Next.js 的课表解析与管理',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className={inter.className} style={{ backgroundColor: '#f3f4f6' }}>
        {children}
        <Script src="https://cdn.tailwindcss.com" strategy="beforeInteractive" />
        <style>{`
          /* Hide scrollbar for clean horizontal scrolling on mobile */
          .no-scrollbar::-webkit-scrollbar { display: none; }
          .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        `}</style>
      </body>
    </html>
  )
}

